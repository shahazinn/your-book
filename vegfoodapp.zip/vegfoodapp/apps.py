from django.apps import AppConfig


class VegfoodappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vegfoodapp'
