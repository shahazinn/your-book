from django.shortcuts import render,redirect
from bitapp.models import bitdb,prodb
from vegfoodapp.models import CustomerDetailes

# Create your views here.
def index4(request):
    data=bitdb.objects.all()
    return render(request,"index1.html",{'data':data})

def contactpage(request):
    data = bitdb.objects.all()
    return render(request,"contact.html",{'data':data})

def aboutpage(request):
    data = bitdb.objects.all()
    return render(request,"about.html",{'data':data})
def blogpage(request):
    data = bitdb.objects.all()
    return render(request,"blog.html",{'data':data})
def product3(request):
    data=prodb.objects.all()
    return render(request,"product.html",{'data':data})
def discategory(request,itemcatg):
    data=bitdb.objects.all()

    print("===itemcatg===",itemcatg)
    catg=itemcatg.upper()

    products=prodb.objects.filter(category=itemcatg)
    context={
        'products':products,
        'catg':catg,
        'data':data,


    }
    return render(request,"categorydisplay.html",context)

def prodetails(request,dataid):
    datas=prodb.objects.get(id=dataid)
    data=bitdb.objects.all()
    return render(request,"productdetails.html",{'dat':datas,'data':data})

def logregpage(request):
    data=bitdb.objects.all()
    return render(request,"logreg.html",{'data':data})
def regdata(request):
    if request.method=="POST":
        username=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('pass1')
        confirm_password=request.POST.get('pass2')
        if password==confirm_password:
            obj=CustomerDetailes(username=username,email=email,password=password,confirm_password=confirm_password)
            obj.save()
            return redirect(logregpage)
        else:
            return render(request,"logreg.html",{'msg':"sorry password not matched"})


